import React, { Component } from "react";


// Stateless Functional Component
class NavBar extends Component {
    render () {
      return (
          <div className="banner">
            <div className="bannerText">
              NavBar
            </div>
          </div>
      );
    };
  };

export default NavBar;
